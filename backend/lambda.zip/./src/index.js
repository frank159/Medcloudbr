"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const app_1 = __importDefault(require("./app"));
const createPatient_1 = __importDefault(require("./endPoints/createPatient"));
const getUser_1 = __importDefault(require("./endPoints/getUser"));
const deletePatient_1 = __importDefault(require("./endPoints/deletePatient"));
const getDetalhes_1 = __importDefault(require("./endPoints/getDetalhes"));
const lbn_lambda_express_1 = require("lbn-lambda-express");
app_1.default.post('/user/signup', createPatient_1.default);
app_1.default.get('/user/get', getUser_1.default);
app_1.default.delete('/user/delete', deletePatient_1.default);
app_1.default.get('/user/:id', getDetalhes_1.default);
exports.handler = lbn_lambda_express_1.createLambdaHandler(app_1.default);
