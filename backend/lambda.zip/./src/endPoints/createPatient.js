"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const connection_1 = __importDefault(require("../connection"));
const idGenerator_1 = require("../services/idGenerator");
const authenticator_1 = require("../services/authenticator");
function createUser(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const { name, email, age, birthday, historic, mothersName, entrance, released } = req.body;
            if (!name || !email || !age || !birthday || !historic || !mothersName || !entrance) {
                res.statusCode = 422;
                throw new Error("Preencha os campos 'name, email, age, birthday, historic, mothersName, entrance");
            }
            const [user] = yield connection_1.default('patient')
                .where({ email });
            if (user) {
                res.statusCode = 409;
                throw new Error('Email já cadastrado');
            }
            const id = idGenerator_1.generateId();
            const newUser = {
                id,
                name,
                email,
                age,
                birthday,
                historic,
                mothersName,
                entrance,
                released
            };
            yield connection_1.default('patient')
                .insert(newUser);
            const token = authenticator_1.generateToken({
                id
            });
            res.status(201).send({ patient: newUser, token });
        }
        catch (error) {
            res.status(400).send({ message: error.message });
        }
    });
}
exports.default = createUser;
